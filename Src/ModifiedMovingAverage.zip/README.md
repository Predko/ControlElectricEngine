# ModifiedMovingAverage
ModifiedMovingAverage - вычисление модифицированного скользящего среднего
